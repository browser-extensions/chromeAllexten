## Panli app webView 开发测试调试利器

>v0.0.2

攻克淘宝的 哈希 元素 模糊查找元素删除

> 目前已经实现 tmall.com ,taobao.com, jd.com 

等待陆续添加


>v0.0.1

方便panli  开发人员在测试 浏览页面时 观察结果

Panli webView去除webapp厂家浮动层

> 目前只支持 tmall.com  和 jd.com 

由于淘宝 的 浮动层为 随机算法哈希值生成 元素的 `id` 和 `class`

无法获取 元素 以及操作元素

## 内部使用, 暂不上传应用商店

本应用仅供开发测试使用 ，请误做非法错误,如有无法判断的事件，作者概不负责。


## 如何安装

1. 请先下载本程序 解压出来, 然后打开谷歌浏览器,在浏览器地址输入 `chrome://extensions/` 

2. ![](./help/images/1.png)


3. ![](./help/images/2.png)

4. 然后浏览器 各个厂家的 webapp 页面把, 网速慢的情况下 ，你会看到 各个厂家的 浮动层 消失


5. 安装好后 浏览器访问 

https://detail.m.tmall.com/item.htm?id=521628888465, 

http://item.m.jd.com/product/1098344.html,


http://h5.m.taobao.com/awp/core/detail.htm?id=525658240175